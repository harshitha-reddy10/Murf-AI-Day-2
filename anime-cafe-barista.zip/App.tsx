import React, { useState, useEffect, useRef, useCallback, memo } from 'react';
import { 
  GoogleGenAI, 
  LiveServerMessage, 
  Modality, 
  FunctionDeclaration, 
  Type 
} from '@google/genai';
import { Mic, MicOff, Coffee, Sparkles, Volume2, AlertCircle, Loader2 } from 'lucide-react';
import { ChatMessage, ConnectionStatus, OrderState } from './types';
import * as AudioUtils from './utils/audioStreamer';
import Visualizer from './components/Visualizer';

// --- Configuration ---
// NOTE: process.env.API_KEY is injected by the environment.
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';

const SYSTEM_INSTRUCTION = `
You are the friendly voice barista of "Anime Cafe", an energetic, cozy, anime-themed coffee shop. 
Your personality is warm, cheerful, slightly playful, and very polite—like a friendly barista in a cute anime café.
You take orders through natural voice conversation.

☕ Barista Behavior Rules (Must Follow Exactly)

You manage an internal order state:
{
  "drinkType": "string",
  "size": "string",
  "milk": "string",
  "extras": ["string"],
  "name": "string"
}

1. Always start with a friendly barista greeting. Example: "Welcome to anime cafe! What can I get started for you today?"
2. Collect the order step-by-step. You MUST ask ONE question at a time, in this exact order:
   - Drink type
   - Size
   - Milk type
   - Extras
   - Customer name
   Only move to the next question after the current field is filled.
3. Do NOT confirm the order until ALL fields are complete.
4. When the order is fully collected, respond EXACTLY like this verbally:
   "✅ ORDER CONFIRMED! Here is your coffee order: Drink: [Drink], Size: [Size], Milk: [Milk], Extras: [Extras], Name: [Name]."
   
   IMMEDIATELY after speaking the confirmation, you MUST call the function "submitOrder" with the collected details. This is critical.

📏 Additional Rules
- If user gives multiple details in one sentence, parse everything you can, then ask for missing fields.
- If user says "no extras", set extras to [].
- Normalize synonyms (big -> large, regular -> medium).
- If unclear, politely ask again.
- Tone: Use expressions like "Hehe~ sure thing!", "You got it!", "Let me ask you the next thing~".

IMPORTANT: Do not output raw JSON text in your speech. Use the function call to submit the JSON.
`;

// --- Function Declarations ---
const submitOrderTool: FunctionDeclaration = {
  name: 'submitOrder',
  description: 'Submits the final coffee order when all details are collected.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      drinkType: { type: Type.STRING, description: 'Type of drink (Latte, Mocha, etc.)' },
      size: { type: Type.STRING, description: 'Size of drink (Small, Medium, Large)' },
      milk: { type: Type.STRING, description: 'Type of milk (Whole, Oat, Almond, etc.)' },
      extras: { 
        type: Type.ARRAY, 
        items: { type: Type.STRING },
        description: 'List of extras like syrup, sugar, whipped cream.'
      },
      name: { type: Type.STRING, description: 'Name of the customer' }
    },
    required: ['drinkType', 'size', 'milk', 'name']
  }
};

// --- Sub-Components ---

const MessageBubble = memo(({ msg }: { msg: ChatMessage }) => {
  const isUser = msg.role === 'user';
  return (
    <div className={`flex w-full mb-4 ${isUser ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 fade-in duration-300`}>
      <div className={`max-w-[80%] p-4 rounded-2xl shadow-sm ${
        isUser 
          ? 'bg-pink-500 text-white rounded-tr-none' 
          : 'bg-white text-gray-700 border border-pink-100 rounded-tl-none'
      }`}>
        <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
      </div>
    </div>
  );
});

const OrderTicket = memo(({ currentOrder }: { currentOrder: OrderState | null }) => {
  if (!currentOrder) return (
    <div className="h-full flex flex-col items-center justify-center text-pink-300 opacity-50 min-h-[300px]">
      <Coffee size={48} className="mb-2" />
      <p className="font-display">No active order</p>
    </div>
  );

  return (
    <div className="animate-in fade-in slide-in-from-bottom duration-500 bg-white p-6 rounded-xl shadow-lg border-2 border-pink-100 relative overflow-hidden">
      {currentOrder.status === 'confirmed' && (
        <div className="absolute top-0 left-0 w-full bg-green-400 text-white text-center text-xs font-bold py-1 tracking-widest uppercase z-10">
          Confirmed
        </div>
      )}
      <h3 className="font-display text-2xl text-pink-600 mb-4 mt-2 flex items-center gap-2">
        <Sparkles size={20} /> Ticket #{Math.floor(Math.random() * 1000)}
      </h3>
      
      <div className="space-y-3 text-gray-700">
        <TicketRow label="Customer" value={currentOrder.name} />
        <TicketRow label="Drink" value={currentOrder.drinkType} />
        <TicketRow label="Size" value={currentOrder.size} />
        <TicketRow label="Milk" value={currentOrder.milk} />
        
        <div className="pt-2 border-t border-dashed border-pink-100">
          <span className="text-gray-400 text-sm block mb-1">Extras</span>
          <div className="flex flex-wrap gap-1">
            {currentOrder.extras && currentOrder.extras.length > 0 ? (
              currentOrder.extras.map((ex, i) => (
                <span key={i} className="px-2 py-1 bg-pink-100 text-pink-600 text-xs rounded-full border border-pink-200">
                  {ex}
                </span>
              ))
            ) : (
              <span className="text-gray-300 text-xs italic">None</span>
            )}
          </div>
        </div>
      </div>
      
      <div className="mt-6 flex items-center justify-center opacity-10 absolute bottom-0 right-0 pointer-events-none transform translate-x-1/4 translate-y-1/4">
        <Coffee size={128} className="text-pink-500" />
      </div>
    </div>
  );
});

const TicketRow = ({ label, value }: { label: string, value: string }) => (
  <div className="flex justify-between items-center border-b border-dashed border-pink-50 pb-2 last:border-0">
    <span className="text-gray-400 text-sm">{label}</span>
    <span className="font-bold text-gray-800 capitalize">{value || "—"}</span>
  </div>
);

const App: React.FC = () => {
  // --- State ---
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentOrder, setCurrentOrder] = useState<OrderState | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // --- Refs ---
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const activeSessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const mountedRef = useRef(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Cleanup on unmount
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      disconnect();
    };
  }, []);

  const disconnect = useCallback(() => {
    if (activeSessionRef.current) {
       try { activeSessionRef.current.close(); } catch (e) { console.warn(e); }
       activeSessionRef.current = null;
    }
    
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }

    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }
    
    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }

    audioSourcesRef.current.forEach(source => {
      try { source.stop(); } catch(e) {}
    });
    audioSourcesRef.current.clear();

    if (mountedRef.current) {
      setStatus('disconnected');
      setIsSpeaking(false);
    }
    nextStartTimeRef.current = 0;
  }, []);

  const connectToGemini = async () => {
    try {
      if (!process.env.API_KEY) {
        throw new Error("API Key not found. Please check your environment configuration.");
      }

      setStatus('connecting');
      setErrorMsg(null);
      setCurrentOrder(null);
      setMessages([]);

      // 1. Setup Audio Contexts
      // IMPORTANT: Do NOT force sampleRate in the constructor. Let the browser decide.
      // We will handle resampling manually.
      const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      
      const inputCtx = new AudioContextClass(); // Standard context
      inputAudioContextRef.current = inputCtx;
      await inputCtx.resume();

      const outputCtx = new AudioContextClass(); // Standard context
      outputAudioContextRef.current = outputCtx;
      await outputCtx.resume();

      // 2. Get Microphone Access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true 
        } 
      });
      mediaStreamRef.current = stream;

      // 3. Initialize Gemini Client
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      // 4. Connect Live Session
      const sessionPromise = ai.live.connect({
        model: MODEL_NAME,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ functionDeclarations: [submitOrderTool] }],
          inputAudioTranscription: {}, // Empty object per docs
          outputAudioTranscription: {}, // Empty object per docs
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } }
          }
        },
        callbacks: {
          onopen: () => {
            if (!mountedRef.current) return;
            console.log('Gemini Live Session Opened');
            setStatus('connected');
            
            sessionPromise.then(sess => {
                if (mountedRef.current) activeSessionRef.current = sess;
            });

            // Start Input Pipeline
            if (!inputAudioContextRef.current || !stream) return;
            
            const source = inputAudioContextRef.current.createMediaStreamSource(stream);
            const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            scriptProcessorRef.current = processor;

            processor.onaudioprocess = (e) => {
              if (!mountedRef.current) return;
              
              const inputData = e.inputBuffer.getChannelData(0);
              
              // CRITICAL: Resample to 16kHz before sending
              const currentSampleRate = inputAudioContextRef.current?.sampleRate || 48000;
              const resampledData = AudioUtils.resampleTo16k(inputData, currentSampleRate);
              const pcmBlob = AudioUtils.createPcmBlob(resampledData);
              
              sessionPromise.then((session) => {
                if (mountedRef.current && session) {
                   session.sendRealtimeInput({ media: pcmBlob });
                }
              }).catch(err => {
                 // Suppress loop errors if session is closed
              });
            };

            source.connect(processor);
            processor.connect(inputAudioContextRef.current.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (!mountedRef.current) return;
            
            // 1. Handle Function Calls
            if (msg.toolCall) {
              for (const fc of msg.toolCall.functionCalls) {
                if (fc.name === 'submitOrder') {
                  setCurrentOrder({ ...fc.args as any, status: 'confirmed' });
                  sessionPromise.then((session) => {
                    session.sendToolResponse({
                      functionResponses: {
                        id: fc.id,
                        name: fc.name,
                        response: { result: "Order logged." }
                      }
                    });
                  });
                }
              }
            }

            // 2. Handle Audio Output
            const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              // Reset time if fell behind
              if (nextStartTimeRef.current < ctx.currentTime) {
                 nextStartTimeRef.current = ctx.currentTime;
              }
              
              try {
                // Decode the 24kHz raw PCM from Gemini
                const audioBuffer = await AudioUtils.decodeAudioData(
                  AudioUtils.decode(audioData),
                  ctx,
                  24000 // Force 24kHz interpretation
                );
                
                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                
                audioSourcesRef.current.add(source);
                setIsSpeaking(true);
                
                source.onended = () => {
                  if (mountedRef.current) {
                    audioSourcesRef.current.delete(source);
                    if (audioSourcesRef.current.size === 0) setIsSpeaking(false);
                  }
                };
              } catch (e) {
                console.error('Audio decode error', e);
              }
            }

            // 3. Handle Transcriptions
            const inputTrans = msg.serverContent?.inputTranscription?.text;
            if (inputTrans) {
               setMessages(prev => {
                  const last = prev[prev.length - 1];
                  if (last && last.role === 'user') {
                     return [...prev.slice(0, -1), { ...last, text: last.text + inputTrans }];
                  }
                  return [...prev, { role: 'user', text: inputTrans, timestamp: Date.now() }];
               });
            }

            const outputTrans = msg.serverContent?.outputTranscription?.text;
            if (outputTrans) {
               setMessages(prev => {
                  const last = prev[prev.length - 1];
                  if (last && last.role === 'model') {
                      return [...prev.slice(0, -1), { ...last, text: last.text + outputTrans }];
                  }
                  return [...prev, { role: 'model', text: outputTrans, timestamp: Date.now() }];
               });
            }
            
            // 4. Handle Interruption
            if (msg.serverContent?.interrupted) {
              audioSourcesRef.current.forEach(s => { try { s.stop(); } catch (e) {} });
              audioSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsSpeaking(false);
            }
          },
          onclose: (e) => {
            console.log('Session closed', e);
            if (mountedRef.current) setStatus('disconnected');
          },
          onerror: (err) => {
            console.error('Session error', err);
            if (mountedRef.current) {
               const msg = err instanceof Error ? err.message : "Connection error";
               setErrorMsg(`Connection lost: ${msg}`);
               setStatus('error');
               disconnect();
            }
          }
        }
      });
      
    } catch (err: any) {
      console.error('Connection Init Failed', err);
      setErrorMsg(err.message || "Failed to initialize connection");
      setStatus('error');
      disconnect();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center p-4 md:p-8">
      <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-12 gap-6 h-[90vh] max-h-[800px]">
        
        {/* Left Panel: Barista Interaction */}
        <div className="lg:col-span-8 bg-white/80 backdrop-blur-md rounded-3xl shadow-xl border border-white flex flex-col overflow-hidden relative z-10">
          
          {/* Header */}
          <div className="bg-pink-500 p-4 text-white flex items-center justify-between shadow-md z-20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-pink-500 shadow-inner">
                <Coffee size={20} strokeWidth={3} />
              </div>
              <div>
                <h1 className="font-display text-xl font-bold leading-none">Anime Cafe</h1>
                <span className="text-xs text-pink-100 opacity-90 font-medium">Voice AI Agent</span>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-pink-600/50 px-3 py-1 rounded-full">
              <div className={`h-2 w-2 rounded-full ${status === 'connected' ? 'bg-green-400 animate-pulse' : status === 'connecting' ? 'bg-yellow-400' : 'bg-red-400'}`}></div>
              <span className="text-xs font-bold uppercase tracking-wide">{status}</span>
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 overflow-y-auto p-6 bg-gradient-to-b from-white to-pink-50/30 space-y-4 scroll-smooth">
             {messages.length === 0 && status === 'connected' && (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 space-y-2 opacity-70">
                   <Coffee size={40} className="mb-2 text-pink-200" />
                   <p className="font-medium">Say <span className="text-pink-500 font-bold">"Hello"</span> to start ordering!</p>
                </div>
             )}
             
             {messages.map((m, i) => (
               <MessageBubble key={`${m.timestamp}-${i}`} msg={m} />
             ))}
             <div ref={messagesEndRef} />
          </div>

          {/* Controls */}
          <div className="p-6 bg-white border-t border-pink-100 shadow-2xl z-20">
             
             {/* Visualizer */}
             <div className="mb-6 flex justify-center">
                <Visualizer isActive={status === 'connected' && isSpeaking} color="#ec4899" />
             </div>

             <div className="flex flex-col items-center justify-center gap-4">
                {status === 'disconnected' || status === 'error' ? (
                  <button 
                    onClick={connectToGemini}
                    className="group relative flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white rounded-full shadow-lg hover:shadow-pink-200 transition-all active:scale-95 w-full sm:w-auto justify-center"
                  >
                    <Mic className="w-6 h-6" />
                    <span className="font-display font-bold text-lg">Start Conversation</span>
                  </button>
                ) : status === 'connecting' ? (
                   <button disabled className="flex items-center gap-3 px-8 py-4 bg-gray-100 text-gray-400 rounded-full w-full sm:w-auto justify-center cursor-wait">
                    <Loader2 className="w-6 h-6 animate-spin" />
                    <span className="font-bold">Connecting...</span>
                  </button>
                ) : (
                   <button 
                    onClick={disconnect}
                    className="flex items-center gap-3 px-8 py-4 bg-white hover:bg-red-50 text-gray-600 hover:text-red-500 rounded-full transition-all active:scale-95 border-2 border-gray-100 w-full sm:w-auto justify-center"
                  >
                    <MicOff className="w-6 h-6" />
                    <span className="font-bold">End Session</span>
                  </button>
                )}
                
                {errorMsg && (
                  <div className="flex items-center gap-2 text-red-500 text-sm bg-red-50 px-4 py-2 rounded-lg animate-in fade-in slide-in-from-bottom-2">
                    <AlertCircle size={16} />
                    <p>{errorMsg}</p>
                  </div>
                )}
             </div>
          </div>
        </div>

        {/* Right Panel: Order State */}
        <div className="lg:col-span-4 flex flex-col gap-6 relative">
           {/* Background Element */}
           <div className="absolute top-0 right-0 w-full h-full bg-white/30 rounded-3xl -z-10 blur-xl"></div>

           {/* Current Order Card */}
           <div className="bg-white/80 backdrop-blur-md rounded-3xl shadow-lg border border-white p-6 flex-1 flex flex-col overflow-hidden">
              <h2 className="font-display text-xl text-gray-700 mb-6 flex items-center gap-2 border-b border-pink-100 pb-4">
                <div className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center text-pink-500">
                   <Volume2 size={16} />
                </div>
                Current Order
              </h2>
              <div className="flex-1 overflow-y-auto">
                <OrderTicket currentOrder={currentOrder} />
              </div>
           </div>

           {/* Instructions Card */}
           <div className="bg-gradient-to-br from-pink-500 to-purple-600 rounded-3xl shadow-lg p-6 text-white relative overflow-hidden">
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-white rounded-full opacity-10 blur-2xl"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-400 rounded-full opacity-20 blur-xl"></div>
              
              <h3 className="font-display text-lg font-bold mb-3 relative z-10 flex items-center gap-2">
                <Sparkles size={18} className="text-yellow-300" /> How to Order
              </h3>
              <ul className="text-sm text-pink-50 space-y-3 relative z-10">
                 <li className="flex items-start gap-2">
                   <span className="bg-white/20 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</span>
                   <span>Say "Hi" to greet the barista.</span>
                 </li>
                 <li className="flex items-start gap-2">
                   <span className="bg-white/20 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</span>
                   <span>Answer questions one by one (Drink, Size, Milk, Extras).</span>
                 </li>
                 <li className="flex items-start gap-2">
                   <span className="bg-white/20 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</span>
                   <span>Confirm your name to finish!</span>
                 </li>
              </ul>
           </div>
        </div>

      </div>
    </div>
  );
};

export default App;