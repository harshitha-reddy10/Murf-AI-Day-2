import React, { useEffect, useRef } from 'react';

interface VisualizerProps {
  isActive: boolean;
  color?: string;
}

const Visualizer: React.FC<VisualizerProps> = ({ isActive, color = "#ec4899" }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let offset = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      if (!isActive) {
        // Idle line
        ctx.beginPath();
        ctx.moveTo(0, canvas.height / 2);
        ctx.lineTo(canvas.width, canvas.height / 2);
        ctx.strokeStyle = '#fbcfe8'; // Pink-200
        ctx.lineWidth = 2;
        ctx.stroke();
        return;
      }

      ctx.beginPath();
      ctx.lineWidth = 3;
      ctx.strokeStyle = color;
      
      const width = canvas.width;
      const height = canvas.height;
      const centerY = height / 2;
      
      ctx.moveTo(0, centerY);

      // Simple sine wave animation simulating voice activity
      for (let x = 0; x < width; x++) {
        const y = centerY + Math.sin((x + offset) * 0.05) * 15 * Math.sin((x + offset) * 0.01);
        ctx.lineTo(x, y);
      }

      ctx.stroke();
      offset += 2;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [isActive, color]);

  return (
    <canvas 
      ref={canvasRef} 
      width={300} 
      height={60} 
      className="w-full h-16 rounded-lg bg-pink-50/50"
    />
  );
};

export default Visualizer;