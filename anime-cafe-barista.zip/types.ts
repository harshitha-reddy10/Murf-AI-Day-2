export interface OrderState {
  drinkType: string;
  size: string;
  milk: string;
  extras: string[];
  name: string;
  status: 'pending' | 'confirmed';
}

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  text: string;
  timestamp: number;
}

export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';
